/*
 * Copyright 2013-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package videoshop.inventory;

import org.salespointframework.inventory.InventoryItem;
import org.salespointframework.inventory.UniqueInventory;
import org.salespointframework.inventory.UniqueInventoryItem;
import org.salespointframework.quantity.Quantity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import videoshop.catalog.VideoCatalog;
import videoshop.catalog.Disc;

// Straight forward?

@Controller
class InventoryController {

	private static final Quantity NONE = Quantity.of(0);
	private static final Quantity basis = Quantity.of(22);

	private final UniqueInventory<UniqueInventoryItem> inventory;
	

	InventoryController(UniqueInventory<UniqueInventoryItem> inventory) {
		this.inventory = inventory;
	}

	/**
	 * Displays all {@link InventoryItem}s in the system
	 *
	 * @param model will never be {@literal null}.
	 * @return the view name.
	 */
	@PostMapping("/stock")
	@PreAuthorize("hasRole('BOSS')")
		String refill(@PathVariable Disc disc, Model model){
		
		var quantity = inventory.findByProductIdentifier(disc.getId()) //
				.map(InventoryItem::getQuantity) //
				.orElse(NONE);

		quantity.add(basis);
		
		return "refillstock" + quantity ;
		
	}
	
	@GetMapping("/stock")//pls change
	@PreAuthorize("hasRole('BOSS')")
	String stock(Model model) {

		model.addAttribute("stock", inventory.findAll());
		
		

		return "stock";
	}

	@GetMapping("/reorder")
	@PreAuthorize("hasRole('BOSS')")
	String reorder(Model model) {
		
		model.addAttribute("emptystock" , inventory.findItemsOutOfStock());
		

		return "reorder";
	}

	public Quantity add(Quantity other) {
		other = basis;
		return other;
		
	}
	@RequestMapping(value ="/reorder", params = {"refillstock"})//pls change
	@PreAuthorize("hasRole('BOSS')")
	public String formhandle(final Quantity quantity) {
		quantity.add(basis);

		return "quantity";
	}
	
}
